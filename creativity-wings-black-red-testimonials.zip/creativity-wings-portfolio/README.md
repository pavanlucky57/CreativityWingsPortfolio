# CREATIVITY WINGS — Portfolio Website

A responsive, premium-cinematic portfolio website built with HTML, CSS and vanilla JavaScript.

## 1. Open in VS Code
1. Download and extract `creativity-wings-portfolio.zip`.
2. Open VS Code.
3. Select **File → Open Folder** and choose `creativity-wings-portfolio`.
4. Install the **Live Server** extension (Ritwick Dey).
5. Right-click `index.html` and choose **Open with Live Server**.

You can also open `index.html` directly in a browser, but Live Server is recommended.

## 2. Add your profile photo and videos

Place your files inside the `assets` folder. Keep these exact names, or update the matching paths in `index.html`.

| File name | Used for |
|---|---|
| `pavan-profile.jpg` | About section portrait |
| `hero-showreel.jpg` | Main hero image / showreel still |
| `project-01.mp4` | Event film |
| `project-01.jpg` | Event film thumbnail |
| `project-02.mp4` | Wedding film |
| `project-02.jpg` | Wedding thumbnail |
| `project-03.mp4` | Commercial film |
| `project-03.jpg` | Commercial thumbnail |
| `project-04.mp4` | Editing reel |
| `project-04.jpg` | Editing thumbnail |

Use compressed MP4 (H.264) videos for smoother loading. For the hero, use a high-quality still image from your showreel. The portfolio cards use native video controls.

## 3. Add your contact details
Open `js/config.js` and replace the empty values:
- `whatsapp`: country code + number, digits only. Example `919876543210`.
- `instagram`: your Instagram profile URL.
- `email`: your enquiry email.
- `phone`: your phone number, including country code.

Do not publish personal contact details unless you want them public.

## 4. Personalise the content
- Change the about paragraph in `index.html` to your real experience and story.
- Rename project titles and categories to match your work.
- Add more projects by duplicating a `.work-card` block and updating its video, poster, title and `data-category`.
- To show your personal profile PNG in the small square where the CW mark appears, save it as `assets/profile.png`. Keep the existing brand text beside it. The same profile image appears in the header and footer.

## 5. Publish the website
Beginner-friendly options include GitHub Pages, Netlify or Vercel static hosting. Upload the project folder (or connect its GitHub repository), then add your custom domain if you have one.

## Notes
- The website is a front-end portfolio; it does not include a server, payment system or booking database.
- Contact buttons become active when you enter your details in `js/config.js`.
- Fonts load from Google Fonts; an internet connection is needed for those fonts. The site remains usable if they are unavailable.

## Updated brand details
- Theme: Premium cinematic.
- Colours: Black and red.
- Pavan K. is identified as Founder.
- Replace `[CO-FOUNDER NAME]` in `index.html` with the actual co-founder's name.

## Testimonials
The Testimonials section is included. It intentionally starts with a request for genuine feedback rather than invented reviews. Replace its introductory message with actual client names, service details and exact feedback as you receive them. Add star ratings only when clients have provided them.

## Profile PNG
Place your personal profile PNG at `assets/profile.png`. This replaces the CW monogram in the header and footer. The supplied brand logo remains in the assets folder as a backup.
