/* Add your real contact details here. Keep the country code in WhatsApp number, digits only. */
window.CW_CONFIG = {
  whatsapp: "", // Example: "919876543210"
  instagram: "https://www.instagram.com/creativity_wings/",
  email: "",    // Example: "hello@creativitywings.in"
  phone: ""     // Example: "+91 98765 43210"
};