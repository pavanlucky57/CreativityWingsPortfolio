const menuButton=document.querySelector('.menu-toggle');
const nav=document.querySelector('.nav');
menuButton.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuButton.setAttribute('aria-expanded',String(open));});
nav.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{nav.classList.remove('open');menuButton.setAttribute('aria-expanded','false');}));
document.querySelector('#year').textContent=new Date().getFullYear();

const revealObserver=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');revealObserver.unobserve(entry.target);}});},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));

document.querySelectorAll('.filter-btn').forEach(button=>button.addEventListener('click',()=>{
  document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));
  button.classList.add('active');
  const filter=button.dataset.filter;
  document.querySelectorAll('.work-card').forEach(card=>{card.hidden=filter!=='all'&&card.dataset.category!==filter;});
}));

const config=window.CW_CONFIG||{};
const contactLinks={
  whatsapp:config.whatsapp?`https://wa.me/${config.whatsapp.replace(/\D/g,'')}?text=${encodeURIComponent("Hi Creativity Wings! I'd like to discuss a project.")}`:"",
  instagram:config.instagram||"",
  email:config.email?`mailto:${config.email}?subject=${encodeURIComponent("Project enquiry — Creativity Wings")}`:"",
  phone:config.phone?`tel:${config.phone.replace(/\s/g,'')}`:""
};
document.querySelectorAll('[data-contact]').forEach(link=>{
  const url=contactLinks[link.dataset.contact];
  if(url){link.href=url;if(!url.startsWith('mailto:')&&!url.startsWith('tel:')){link.target='_blank';link.rel='noopener noreferrer';}}
  else{link.addEventListener('click',event=>{event.preventDefault();alert('Please add your contact details in js/config.js first.');});}
});

const glow=document.querySelector('.cursor-glow');
window.addEventListener('pointermove',event=>{if(window.innerWidth>800){glow.style.left=event.clientX+'px';glow.style.top=event.clientY+'px';}});
/* Hide placeholder text when a real video source is loaded. */
document.querySelectorAll('.work-media video').forEach(video=>{
  const placeholder=video.parentElement.querySelector('.media-placeholder');
  video.addEventListener('loadeddata',()=>{if(placeholder)placeholder.style.display='none';});
  video.addEventListener('error',()=>{if(placeholder)placeholder.style.display='flex';});
});